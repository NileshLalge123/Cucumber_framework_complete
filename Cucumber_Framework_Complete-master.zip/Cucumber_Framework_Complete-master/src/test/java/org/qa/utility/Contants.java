package org.qa.utility;

public class Contants {
	public static final int small_wait = 30;
}
