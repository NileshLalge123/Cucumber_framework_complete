//package stepDefinitions;
//
//import org.pages.CustomerPage;
//import org.qa.factory.DriverFactory;
//
//public class CustomerStepDef {
//	private static String title;
//	private CustomerPage lp = new CustomerPage(DriverFactory.getDriver());
//	
//	
//}
